# Plotstay 评价与回复改版：从这里开始

日期：2026-10-13。用户已确认产品方案和四张线框图。这个交接包用于将它们转成真正可用的中英工作台页面。

## 发给开发的方法

将整个文件夹交给开发，或把它放到开发能够读取的位置并提供路径。附件不一定自动出现在服务器 `/data/apps/plotstay`；不要让开发凭文件名猜已上传位置。

先发送 [`PROMPT-stage-a.md`](PROMPT-stage-a.md) 的内容。首个检查点是独立可点击预览，不是正式页面替换；用户确认该预览后，再发送 [`PROMPT-stage-b.md`](PROMPT-stage-b.md)。两个阶段提示词不要当成一次无条件连续执行的指令。

| 文件 | 内容与用途 |
|---|---|
| [开发交接](plotstay-reviews-development-handoff.md) | 实际基线、图文纠偏、逐页布局、手机与英文、前后端契约、共享范围、阶段门槛。 |
| [验收清单](plotstay-reviews-acceptance-checklist.md) | 预览、视觉、真实数据、并发、历史授权、旧版兼容与部署的逐项检查。 |
| [阶段 A 提示词](PROMPT-stage-a.md) | 先读实际状态，独立预览，交付截图与交互后暂停。 |
| [阶段 B 提示词](PROMPT-stage-b.md) | 预览验收后，真实数据与规则接入、隔离回归和按授权部署。 |
| [原整合方案](decisions/plotstay-reviews-redesign-spec-2026-10-13.md) | 已确认 C01—C13 的产品规则、范围与长期 TODO。文件原有状态文字保留为历史，后续确认以本交接和用户指令为准。 |
| [原讨论记录](decisions/plotstay-reviews-discussion-record-2026-10-13.md) | 各轮已确认决定和 LT-REV-01 的来龙去脉。 |

## 图像参考

| 文件 | 用途 |
|---|---|
| [改版前](reference/00-before-reviews.png) | 同视口对比参考。 |
| [图 01 我的评价](reference/01-my-reviews-desktop.png) | 角色聚焦与评价、公开回复摘要。 |
| [图 02 收到的评价](reference/02-received-reviews-desktop.png) | 评价者与自己的提供者身份、回复状态。 |
| [图 03 评价详情和编辑](reference/03-review-detail-editor-desktop.png) | 完整互动、评价写作与可选字段。 |
| [图 04 回复详情和编辑](reference/04-reply-detail-editor-desktop.png) | 原评价参考、固定署名、回复写作。 |

图像按收到的原始内容复制，仅改成便于引用的文件名，没有修图。它们有已在开发交接第 2 节列明的示意偏差。尤其不要把右侧“设计说明”、通知铃铛、伪“官方身份”、错误字数、错误类型、错误版本状态和只读旁的提交按钮原样开发。

本包不是重新绘制的高保真最终稿；桌面结构方向已确认，具体尺寸、手机、英文及可点击行为需要阶段 A 浏览器验收。图像不替代真实 UI 截图或后端测试。

## 已核对的当前项目变化

交接时 GitHub main 为 `4383ffe48ad8d0adf3517009daaf249d1f509cbc`；角色页已经真实接入，共享导航已调整，`workspace-personas.ts` 和迁移 `011_persona_private_notes.sql` 已存在。开工时必须重新核对实际工作区，不回滚到此前的 `9f42a6b` 或 `f494b1c`。

这次只在对话环境制作交接包，没有连接服务器执行 git、改项目、迁移、部署或更新仓库 TODO。README 中的远端信息来自只读 GitHub 核对；不证明服务器未提交修改情况。

## 三条不可省的控制

1. 不覆盖角色 session 或其他人的未提交修改；公共壳、domain 与迁移先分工。
2. P/A/B 固定版本与旧／新提供者历史私稿隔离是正式需求，不能为了“只改 UI”删掉。
3. 独立预览、真实 API 隔离验证、线上部署验收分别报告；没有做的明确写未验证。

`MANIFEST.sha256` 列出包内输入与交接文件校验值（不包含 manifest 自身）。
